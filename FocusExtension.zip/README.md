# FocusExtension
A Google Chrome Extension to promote productivity and make sure user focus on their current task
