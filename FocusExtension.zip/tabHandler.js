"use strict"

// var tabs = chrome.tabs;
// for (var i = 0; i < tabs.length; i++) {
// 	var tab = tab[i];
// 	if (tab.url.startsWith("https://www.facebook.com")) {
// 		tabs.remove(i);
// 	}
// }

chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab) {
	if (tab.url.startsWith("https://www.facebook.com")) {
		chrome.tabs.remove(tab.id);
	}
});

chrome.tabs.onCreated.addListener(function(tab) {
	if (tab.url.startsWith("https://www.facebook.com")) {
		chrome.tabs.remove(tab.id);
	}
})