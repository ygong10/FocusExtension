"use strict";
var config = {
	apiKey: "AIzaSyAL517jiGa6Xfv8YW6v8247Qc7mWLbcDp4",
	authDomain: "focus-fc061.firebaseapp.com",
	databaseURL: "https://focus-fc061.firebaseio.com",
	storageBucket: "focus-fc061.appspot.com",
	messagingSenderId: "1064226865545"
};