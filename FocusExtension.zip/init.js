"use strict"

firebase.initializeApp(config);

var countdownTimer = 0;
var isTimerRunning = false;




