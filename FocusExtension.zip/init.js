"use strict"

firebase.initializeApp(config);
